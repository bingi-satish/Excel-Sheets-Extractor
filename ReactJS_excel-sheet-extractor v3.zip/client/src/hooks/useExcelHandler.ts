import * as XLSX from 'xlsx';
import ExcelJS from 'exceljs';
import JSZip from 'jszip';

export interface Sheet {
  name: string;
  rowCount: number;
  colCount: number;
}

export const useExcelHandler = () => {
  const parseExcelFile = (file: File): Promise<Sheet[]> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = (e) => {
        try {
          const data = e.target?.result;
          const workbook = XLSX.read(data, { type: 'array' });
          
          const sheets: Sheet[] = workbook.SheetNames.map((name) => {
            const worksheet = workbook.Sheets[name];
            const range = XLSX.utils.decode_range(worksheet['!ref'] || 'A1');
            
            return {
              name,
              rowCount: range.e.r + 1,
              colCount: range.e.c + 1,
            };
          });

          resolve(sheets);
        } catch (error) {
          reject(new Error('Failed to parse Excel file'));
        }
      };

      reader.onerror = () => {
        reject(new Error('Failed to read file'));
      };

      reader.readAsArrayBuffer(file);
    });
  };

  const copySheetWithFormatting = async (sourceSheet: ExcelJS.Worksheet, newSheet: ExcelJS.Worksheet) => {
    // Copy all rows with formatting
    sourceSheet.eachRow((row, rowNumber) => {
      const newRow = newSheet.getRow(rowNumber);

      // Copy row properties
      if (row.height) {
        newRow.height = row.height;
      }
      if (row.hidden) {
        newRow.hidden = row.hidden;
      }
      if (row.outlineLevel) {
        newRow.outlineLevel = row.outlineLevel;
      }

      // Copy each cell with all its properties
      row.eachCell((cell, colNumber) => {
        const newCell = newRow.getCell(colNumber);

        // Copy cell value
        newCell.value = cell.value;

        // Copy cell formatting
        if (cell.numFmt) {
          newCell.numFmt = cell.numFmt;
        }

        // Copy font
        if (cell.font) {
          newCell.font = { ...cell.font };
        }

        // Copy fill (background color)
        if (cell.fill) {
          newCell.fill = { ...cell.fill };
        }

        // Copy border
        if (cell.border) {
          newCell.border = { ...cell.border };
        }

        // Copy alignment
        if (cell.alignment) {
          newCell.alignment = { ...cell.alignment };
        }

        // Copy protection
        if (cell.protection) {
          newCell.protection = { ...cell.protection };
        }
      });
    });

    // Copy column dimensions (width and formatting)
    sourceSheet.columns.forEach((col, colIndex) => {
      if (col) {
        const newCol = newSheet.getColumn(colIndex + 1);
        if (col.width !== undefined) {
          newCol.width = col.width;
        }
        if (col.hidden !== undefined) {
          newCol.hidden = col.hidden;
        }
        if (col.outlineLevel !== undefined) {
          newCol.outlineLevel = col.outlineLevel;
        }
      }
    });

    // Copy merged cells safely
    try {
      if ((sourceSheet as any)._mergedCells && (sourceSheet as any)._mergedCells.length > 0) {
        (sourceSheet as any)._mergedCells.forEach((mergedCell: string) => {
          try {
            newSheet.mergeCells(mergedCell);
          } catch (e) {
            // Skip invalid merged cells
            console.warn('Skipped invalid merged cell:', mergedCell);
          }
        });
      }
    } catch (e) {
      console.warn('Error copying merged cells:', e);
    }
  };

  const extractSheets = (file: File, sheetNames: string[]): Promise<void> => {
    return new Promise(async (resolve, reject) => {
      try {
        const arrayBuffer = await file.arrayBuffer();
        
        // Load the original workbook using ExcelJS to preserve all formatting
        const sourceWorkbook = new ExcelJS.Workbook();
        await sourceWorkbook.xlsx.load(arrayBuffer);

        // Create a new workbook for extracted sheets
        const newWorkbook = new ExcelJS.Workbook();

        // Extract and copy selected sheets with all formatting
        for (const sheetName of sheetNames) {
          const sourceSheet = sourceWorkbook.getWorksheet(sheetName);
          
          if (sourceSheet) {
            // Create new sheet with same properties
            const newSheet = newWorkbook.addWorksheet(sourceSheet.name);

            // Copy formatting
            await copySheetWithFormatting(sourceSheet, newSheet);
          }
        }

        // Generate filename with timestamp
        const originalName = file.name.replace(/\.[^/.]+$/, '');
        const timestamp = new Date().toISOString().slice(0, 10);
        const newFileName = `${originalName}_extracted_${timestamp}.xlsx`;

        // Write the file
        const buffer = await newWorkbook.xlsx.writeBuffer();
        const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        
        // Trigger download
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = newFileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);

        resolve();
      } catch (error) {
        console.error('Extraction error:', error);
        reject(new Error('Failed to extract sheets with formatting'));
      }
    });
  };

  const extractIndividualSheetsAsZip = (file: File, sheetNames: string[]): Promise<void> => {
    return new Promise(async (resolve, reject) => {
      try {
        const arrayBuffer = await file.arrayBuffer();
        
        // Load the original workbook using ExcelJS
        const sourceWorkbook = new ExcelJS.Workbook();
        await sourceWorkbook.xlsx.load(arrayBuffer);

        const originalName = file.name.replace(/\.[^/.]+$/, '');
        const timestamp = new Date().toISOString().slice(0, 10);
        const zip = new JSZip();

        // Extract each sheet as an individual file and add to ZIP
        for (const sheetName of sheetNames) {
          const sourceSheet = sourceWorkbook.getWorksheet(sheetName);
          
          if (sourceSheet) {
            // Create a new workbook for this sheet
            const newWorkbook = new ExcelJS.Workbook();

            // Create new sheet with same properties
            const newSheet = newWorkbook.addWorksheet(sourceSheet.name);

            // Copy formatting
            await copySheetWithFormatting(sourceSheet, newSheet);

            // Write the file to buffer
            const buffer = await newWorkbook.xlsx.writeBuffer();
            
            // Add to ZIP with sheet name as filename
            zip.file(`${sheetName}.xlsx`, buffer);
          }
        }

        // Generate ZIP filename
        const zipFileName = `${originalName}_sheets_${timestamp}.zip`;

        // Generate ZIP file
        const zipBlob = await zip.generateAsync({ type: 'blob' });
        
        // Trigger download
        const url = URL.createObjectURL(zipBlob);
        const link = document.createElement('a');
        link.href = url;
        link.download = zipFileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);

        resolve();
      } catch (error) {
        console.error('ZIP extraction error:', error);
        reject(new Error('Failed to extract sheets as ZIP'));
      }
    });
  };

  const extractIndividualSheets = (file: File, sheetNames: string[]): Promise<void> => {
    return new Promise(async (resolve, reject) => {
      try {
        const arrayBuffer = await file.arrayBuffer();
        
        // Load the original workbook using ExcelJS
        const sourceWorkbook = new ExcelJS.Workbook();
        await sourceWorkbook.xlsx.load(arrayBuffer);

        // Extract each sheet as an individual file
        for (const sheetName of sheetNames) {
          const sourceSheet = sourceWorkbook.getWorksheet(sheetName);
          
          if (sourceSheet) {
            // Create a new workbook for this sheet
            const newWorkbook = new ExcelJS.Workbook();

            // Create new sheet with same properties
            const newSheet = newWorkbook.addWorksheet(sourceSheet.name);

            // Copy formatting
            await copySheetWithFormatting(sourceSheet, newSheet);

            // Write the file
            const buffer = await newWorkbook.xlsx.writeBuffer();
            const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
            
            // Trigger download
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `${sheetName}.xlsx`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);

            // Small delay between downloads to avoid browser issues
            await new Promise(resolve => setTimeout(resolve, 300));
          }
        }

        resolve();
      } catch (error) {
        console.error('Extraction error:', error);
        reject(new Error('Failed to extract sheets as individual files'));
      }
    });
  };

  return { parseExcelFile, extractSheets, extractIndividualSheets, extractIndividualSheetsAsZip };
};
