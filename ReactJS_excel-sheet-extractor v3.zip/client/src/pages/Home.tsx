import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Upload, Download, AlertCircle, CheckCircle2, FileDown, Archive } from 'lucide-react';
import { useExcelHandler, type Sheet } from '@/hooks/useExcelHandler';
import { toast } from 'sonner';

/**
 * Design Philosophy: Modern Minimalist
 * - Clean white background with teal accent (#06b6d4)
 * - Poppins for headings, Inter for body
 * - Minimal shadows, generous whitespace
 * - Smooth transitions and micro-interactions
 */

export default function Home() {
  const [sheets, setSheets] = useState<Sheet[]>([]);
  const [selectedSheets, setSelectedSheets] = useState<Set<string>>(new Set());
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isExtracting, setIsExtracting] = useState(false);
  const [downloadMode, setDownloadMode] = useState<'combined' | 'individual' | 'zip'>('zip');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { parseExcelFile, extractSheets, extractIndividualSheets, extractIndividualSheetsAsZip } = useExcelHandler();

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.name.endsWith('.xlsx') && !file.name.endsWith('.xls')) {
      toast.error('Please upload an Excel file (.xlsx or .xls)');
      return;
    }

    setIsLoading(true);
    try {
      const parsedSheets = await parseExcelFile(file);
      setSheets(parsedSheets);
      setUploadedFile(file);
      setSelectedSheets(new Set());
      toast.success(`Successfully loaded ${parsedSheets.length} sheets`);
    } catch (error) {
      toast.error('Failed to load Excel file');
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSheetToggle = (sheetName: string) => {
    const newSelected = new Set(selectedSheets);
    if (newSelected.has(sheetName)) {
      newSelected.delete(sheetName);
    } else {
      newSelected.add(sheetName);
    }
    setSelectedSheets(newSelected);
  };

  const handleSelectAll = () => {
    if (selectedSheets.size === sheets.length) {
      setSelectedSheets(new Set());
    } else {
      setSelectedSheets(new Set(sheets.map(s => s.name)));
    }
  };

  const handleExtract = async () => {
    if (!uploadedFile || selectedSheets.size === 0) {
      toast.error('Please select at least one sheet to extract');
      return;
    }

    setIsExtracting(true);
    try {
      if (downloadMode === 'zip') {
        await extractIndividualSheetsAsZip(uploadedFile, Array.from(selectedSheets));
        toast.success(`Downloaded ${selectedSheets.size} sheet(s) as ZIP!`);
      } else if (downloadMode === 'individual') {
        await extractIndividualSheets(uploadedFile, Array.from(selectedSheets));
        toast.success(`Downloaded ${selectedSheets.size} sheet(s) as individual files!`);
      } else {
        await extractSheets(uploadedFile, Array.from(selectedSheets));
        toast.success('Sheets extracted and downloaded successfully!');
      }
      setSelectedSheets(new Set());
    } catch (error) {
      toast.error('Failed to extract sheets');
      console.error(error);
    } finally {
      setIsExtracting(false);
    }
  };

  const handleReset = () => {
    setSheets([]);
    setSelectedSheets(new Set());
    setUploadedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container py-6">
          <h1 className="text-4xl font-bold text-foreground">Excel Sheet Extractor</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Upload an Excel file, select sheets, and download them individually, combined, or as a ZIP archive
          </p>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-12">
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Upload Section */}
          <div className="lg:col-span-2">
            <div
              className="flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-border bg-card p-12 transition-all duration-200 hover:border-primary hover:bg-accent/5 cursor-pointer"
              onClick={() => fileInputRef.current?.click()}
            >
              <Upload className="h-12 w-12 text-primary mb-4" />
              <h2 className="text-xl font-semibold text-foreground mb-2">
                {uploadedFile ? uploadedFile.name : 'Upload Excel File'}
              </h2>
              <p className="text-sm text-muted-foreground text-center">
                {uploadedFile
                  ? 'Click to upload a different file'
                  : 'Click to browse or drag and drop your Excel file here'}
              </p>
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx,.xls"
                onChange={handleFileUpload}
                className="hidden"
              />
            </div>

            {/* Sheets List */}
            {sheets.length > 0 && (
              <div className="mt-8">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-foreground">
                    Available Sheets ({sheets.length})
                  </h3>
                  <button
                    onClick={handleSelectAll}
                    className="text-sm text-primary hover:underline transition-colors"
                  >
                    {selectedSheets.size === sheets.length ? 'Deselect All' : 'Select All'}
                  </button>
                </div>

                <div className="space-y-2">
                  {sheets.map((sheet) => (
                    <div
                      key={sheet.name}
                      className="flex items-center gap-3 rounded-lg border border-border bg-card p-4 transition-all duration-200 hover:border-primary hover:shadow-sm"
                    >
                      <Checkbox
                        checked={selectedSheets.has(sheet.name)}
                        onCheckedChange={() => handleSheetToggle(sheet.name)}
                        className="h-5 w-5"
                      />
                      <div className="flex-1">
                        <p className="font-medium text-foreground">{sheet.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {sheet.rowCount} rows × {sheet.colCount} columns
                        </p>
                      </div>
                      {selectedSheets.has(sheet.name) && (
                        <CheckCircle2 className="h-5 w-5 text-primary" />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar - Actions */}
          <div className="lg:col-span-1">
            <Card className="sticky top-8 p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Actions</h3>

              {sheets.length > 0 ? (
                <div className="space-y-4">
                  <div className="rounded-lg bg-accent/10 border border-accent/20 p-3">
                    <p className="text-sm text-foreground">
                      <span className="font-semibold">{selectedSheets.size}</span> of{' '}
                      <span className="font-semibold">{sheets.length}</span> sheets selected
                    </p>
                  </div>

                  {/* Download Mode Selection */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Download Mode:</label>
                    <div className="space-y-2">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="downloadMode"
                          value="zip"
                          checked={downloadMode === 'zip'}
                          onChange={(e) => setDownloadMode(e.target.value as 'combined' | 'individual' | 'zip')}
                          className="w-4 h-4"
                        />
                        <span className="text-sm text-foreground">ZIP Archive</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="downloadMode"
                          value="individual"
                          checked={downloadMode === 'individual'}
                          onChange={(e) => setDownloadMode(e.target.value as 'combined' | 'individual' | 'zip')}
                          className="w-4 h-4"
                        />
                        <span className="text-sm text-foreground">Individual Files</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="downloadMode"
                          value="combined"
                          checked={downloadMode === 'combined'}
                          onChange={(e) => setDownloadMode(e.target.value as 'combined' | 'individual' | 'zip')}
                          className="w-4 h-4"
                        />
                        <span className="text-sm text-foreground">Combined File</span>
                      </label>
                    </div>
                  </div>

                  <Button
                    onClick={handleExtract}
                    disabled={selectedSheets.size === 0 || isExtracting}
                    className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                  >
                    {isExtracting ? (
                      <>
                        <span className="animate-spin mr-2">⏳</span>
                        {downloadMode === 'zip' ? 'Creating ZIP...' : downloadMode === 'individual' ? 'Downloading...' : 'Extracting...'}
                      </>
                    ) : (
                      <>
                        {downloadMode === 'zip' ? (
                          <>
                            <Archive className="h-4 w-4 mr-2" />
                            Download as ZIP
                          </>
                        ) : downloadMode === 'individual' ? (
                          <>
                            <FileDown className="h-4 w-4 mr-2" />
                            Download Individual Files
                          </>
                        ) : (
                          <>
                            <Download className="h-4 w-4 mr-2" />
                            Extract & Download
                          </>
                        )}
                      </>
                    )}
                  </Button>

                  <Button
                    onClick={handleReset}
                    variant="outline"
                    className="w-full"
                  >
                    Reset
                  </Button>
                </div>
              ) : (
                <div className="rounded-lg bg-muted/50 border border-border p-4 text-center">
                  <AlertCircle className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">
                    Upload an Excel file to get started
                  </p>
                </div>
              )}

              {/* Info Section */}
              <div className="mt-6 pt-6 border-t border-border">
                <h4 className="text-sm font-semibold text-foreground mb-3">How it works</h4>
                <ol className="space-y-2 text-xs text-muted-foreground">
                  <li className="flex gap-2">
                    <span className="font-semibold text-primary">1.</span>
                    <span>Upload your Excel file</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-semibold text-primary">2.</span>
                    <span>Select sheets to extract</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-semibold text-primary">3.</span>
                    <span>Choose download mode</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-semibold text-primary">4.</span>
                    <span>Download as file(s)</span>
                  </li>
                </ol>
              </div>

              {/* Mode Descriptions */}
              <div className="mt-6 pt-6 border-t border-border">
                <h4 className="text-sm font-semibold text-foreground mb-3">Download Modes</h4>
                <div className="space-y-3 text-xs text-muted-foreground">
                  <div>
                    <p className="font-medium text-foreground mb-1">ZIP Archive</p>
                    <p>All sheets in one compressed file with original names</p>
                  </div>
                  <div>
                    <p className="font-medium text-foreground mb-1">Individual Files</p>
                    <p>Each sheet as a separate Excel file (sequential download)</p>
                  </div>
                  <div>
                    <p className="font-medium text-foreground mb-1">Combined File</p>
                    <p>All sheets in a single Excel workbook</p>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
