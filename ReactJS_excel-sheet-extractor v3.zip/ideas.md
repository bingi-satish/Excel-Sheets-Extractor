# Excel Sheet Extractor - Design Concepts

## Project Overview
A utility application for extracting sheets from Excel files. Users upload an Excel file, view sheet names, select sheets to extract, and download them as separate files.

---

## Design Concept 1: Modern Minimalist (Probability: 0.08)

**Design Movement:** Swiss Design meets Contemporary SaaS

**Core Principles:**
- Clarity through constraint: Minimal color palette (grayscale + one accent), generous whitespace, and clear hierarchy
- Function-first layout: Every element serves a purpose; no decorative elements
- Precision typography: Geometric sans-serif with strict hierarchy (display, heading, body, caption)
- Subtle depth: Minimal shadows only for interactive elevation, no gradients

**Color Philosophy:**
- Background: Pure white (or near-white at `#fafafa`)
- Primary text: Deep charcoal (`#1a1a1a`)
- Accent: Vibrant teal (`#06b6d4`) for CTAs and highlights
- Borders: Soft gray (`#e5e7eb`)
- Reasoning: Conveys professionalism, trustworthiness, and technical competence

**Layout Paradigm:**
- Vertical flow with asymmetric spacing: Upload zone at top (60% width, left-aligned), sheet list on right sidebar
- Two-column layout: Left for main actions, right for metadata/preview
- Ample padding and breathing room between sections

**Signature Elements:**
1. Geometric upload zone with dashed border and centered icon
2. Minimalist card-based sheet list with hover elevation
3. Checkbox-based selection with smooth transitions

**Interaction Philosophy:**
- Instant feedback: Hover states change background subtly, selections highlight with accent color
- Smooth transitions: 200ms ease-out for all state changes
- Empty states: Friendly, instructional copy with icons

**Animation:**
- File upload: Subtle scale-in (1.02x) on hover
- Sheet selection: Checkbox animates with a 150ms spring (stiffness: 300)
- Extraction progress: Minimal loading bar with gradient pulse

**Typography System:**
- Display: `Poppins` 32px bold (headings)
- Heading: `Poppins` 18px semibold (section titles)
- Body: `Inter` 14px regular (descriptions, labels)
- Caption: `Inter` 12px regular (metadata, hints)

---

## Design Concept 2: Data-Driven Professional (Probability: 0.07)

**Design Movement:** Corporate Dashboard Aesthetic

**Core Principles:**
- Information hierarchy: Data-centric layout with visual weight distribution
- Structured grids: Organized, scannable interface with clear sections
- Accent color for actions: Distinct, clickable elements stand out
- Soft shadows for depth: Layered cards create visual separation

**Color Philosophy:**
- Background: Soft off-white (`#f8f9fa`)
- Primary text: Slate gray (`#334155`)
- Accent: Deep blue (`#2563eb`) for primary actions
- Secondary: Amber (`#f59e0b`) for warnings/extractions
- Reasoning: Conveys authority, reliability, and professional data handling

**Layout Paradigm:**
- Three-zone layout: Header (branding + status), main content (upload + sheet list), sidebar (actions + metadata)
- Grid-based sections with consistent 16px spacing
- Right-aligned action buttons for consistency

**Signature Elements:**
1. Status badge showing file name and sheet count
2. Table-like sheet list with columns (name, rows, columns, size)
3. Action buttons with icon + label

**Interaction Philosophy:**
- Hover states: Subtle background color shift, cursor change
- Selection: Radio buttons or checkboxes with smooth transitions
- Feedback: Toast notifications for success/error states

**Animation:**
- File upload: Fade-in with 300ms ease
- Sheet list: Staggered fade-in for each row (50ms delay)
- Extraction: Progress bar with smooth animation

**Typography System:**
- Display: `Roboto` 28px bold (main title)
- Heading: `Roboto` 16px semibold (section titles)
- Body: `Roboto` 14px regular (content)
- Caption: `Roboto` 12px regular (metadata)

---

## Design Concept 3: Modern Playful (Probability: 0.06)

**Design Movement:** Contemporary Web 3.0 Aesthetic

**Core Principles:**
- Vibrant, gradient-driven: Bold color combinations with smooth gradients
- Rounded corners everywhere: Soft, approachable interface
- Micro-interactions: Every action has delightful feedback
- Layered depth: Multiple shadow layers create floating effect

**Color Philosophy:**
- Background: Gradient from light purple (`#f3e8ff`) to light blue (`#dbeafe`)
- Primary accent: Vibrant purple (`#a855f7`)
- Secondary accent: Bright cyan (`#06b6d4`)
- Text: Dark purple (`#6b21a8`)
- Reasoning: Modern, energetic, approachable; appeals to creative professionals

**Layout Paradigm:**
- Organic, flowing layout: Upload zone as large hero element, sheet list below in masonry-style cards
- Asymmetric spacing: Varied padding creates visual interest
- Floating elements: Cards appear to float above background

**Signature Elements:**
1. Large, gradient-filled upload zone with animated icon
2. Colorful sheet cards with gradient backgrounds
3. Animated checkmarks for selection

**Interaction Philosophy:**
- Playful feedback: Bounce animations, scale transforms on interaction
- Hover states: Cards lift with shadow, icons scale up
- Success states: Confetti-like animation or celebratory feedback

**Animation:**
- File upload: Bounce-in animation (keyframes: 0% scale 0.8, 50% scale 1.1, 100% scale 1)
- Sheet selection: Checkmark with spring animation
- Extraction: Animated progress with color transitions

**Typography System:**
- Display: `Quicksand` 36px bold (main title)
- Heading: `Quicksand` 20px semibold (section titles)
- Body: `Poppins` 14px regular (content)
- Caption: `Poppins` 12px regular (metadata)

---

## Selected Design Approach

**Chosen: Modern Minimalist (Swiss Design meets Contemporary SaaS)**

This approach balances professionalism with usability. The minimalist aesthetic ensures the focus remains on the core functionality—uploading and extracting sheets—without visual distractions. The teal accent color provides a modern touch while maintaining clarity. The asymmetric two-column layout optimizes space and creates a natural flow for users.

**Key Implementation Details:**
- Clean, white background with soft gray borders
- Teal accent color (`#06b6d4`) for interactive elements
- Geometric sans-serif typography (Poppins for display, Inter for body)
- Minimal shadows only for interactive elevation
- Smooth transitions and micro-interactions for feedback
- Generous whitespace and clear visual hierarchy
